﻿using System;
using System.Windows;
using QRCoder;
using System.Drawing;
using System.IO;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace QRcode_Generator
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void InputTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            GenerateQRCode(InputTextBox.Text);
        }

        private void GenerateQRCode(string inputText)
        {
            if (string.IsNullOrEmpty(inputText))
            {
                QRCodeImage.Source = null;
                return;
            }

            // QRコード生成のインスタンスを作成
            QRCoder.QRCodeGenerator qrGenerator = new QRCoder.QRCodeGenerator();
            QRCoder.QRCodeData qrCodeData = qrGenerator.CreateQrCode(inputText, QRCoder.QRCodeGenerator.ECCLevel.Q);
            QRCoder.QRCode qrCode = new QRCoder.QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            QRCodeImage.Source = BitmapToImageSource(qrCodeImage);
        }

        private BitmapImage BitmapToImageSource(Bitmap bitmap)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                memory.Position = 0;
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memory;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
                return bitmapImage;
            }
        }

        private void SaveQRCode_Click(object sender, RoutedEventArgs e)
        {
            if (QRCodeImage.Source == null)
            {
                MessageBox.Show("QRコードが生成されていません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PNGファイル (*.png)|*.png";
            saveFileDialog.FileName = GetDefaultFileName();
            if (saveFileDialog.ShowDialog() == true)
            {
                SaveBitmapSourceAsPng((BitmapSource)QRCodeImage.Source, saveFileDialog.FileName);
            }
        }

        private string GetDefaultFileName()
        {
            return $"Generateqr_{DateTime.Now:yyyyMMddHHmmss}.png";
        }

        private void SaveBitmapSourceAsPng(BitmapSource bitmapSource, string filePath)
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                encoder.Save(stream);
            }
        }
    }
}
