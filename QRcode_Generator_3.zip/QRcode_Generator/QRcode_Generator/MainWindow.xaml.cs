﻿using System;
using System.Windows;
using QRCoder;
using System.Drawing;
using System.IO;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using System.Windows.Controls;
using System.Windows.Media;

namespace QRcode_Generator
{
    public partial class MainWindow : Window
    {
        private System.Drawing.Color qrCodeColor = System.Drawing.Color.Black;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void InputTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            GenerateQRCode(InputTextBox.Text);
        }

        private void GenerateQRCode(string inputText)
        {
            if (string.IsNullOrEmpty(inputText))
            {
                QRCodeImage.Source = null;
                return;
            }

            QRCoder.QRCodeGenerator qrGenerator = new QRCoder.QRCodeGenerator();
            QRCoder.QRCodeData qrCodeData = qrGenerator.CreateQrCode(inputText, QRCoder.QRCodeGenerator.ECCLevel.Q);
            QRCoder.QRCode qrCode = new QRCoder.QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20, qrCodeColor, System.Drawing.Color.White, true);

            QRCodeImage.Source = BitmapToImageSource(qrCodeImage);
        }

        private BitmapImage BitmapToImageSource(Bitmap bitmap)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                memory.Position = 0;
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memory;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
                return bitmapImage;
            }
        }

        private void SaveQRCode_Click(object sender, RoutedEventArgs e)
        {
            if (QRCodeImage.Source == null)
            {
                MessageBox.Show("QRコードが生成されていません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PNGファイル (*.png)|*.png";
            saveFileDialog.FileName = GetDefaultFileName();
            if (saveFileDialog.ShowDialog() == true)
            {
                SaveBitmapSourceAsPng((BitmapSource)QRCodeImage.Source, saveFileDialog.FileName);
            }
        }

        private string GetDefaultFileName()
        {
            return $"Generateqr_{DateTime.Now:yyyyMMddHHmmss}.png";
        }

        private void SaveBitmapSourceAsPng(BitmapSource bitmapSource, string filePath)
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                encoder.Save(stream);
            }
        }

        private void ColorPicker_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<System.Windows.Media.Color?> e)
        {
            if (ColorPicker.SelectedColor.HasValue)
            {
                var selectedColor = ColorPicker.SelectedColor.Value;
                qrCodeColor = System.Drawing.Color.FromArgb(selectedColor.A, selectedColor.R, selectedColor.G, selectedColor.B);
                GenerateQRCode(InputTextBox.Text);
            }
        }
    }
}
